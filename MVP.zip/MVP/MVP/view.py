# -*- coding: utf-8 -*-

# from django.http import HttpResponse
import os

from django.http import HttpResponse
from django.shortcuts import render


# def hello(request):
#     context = {}
#     context['hello'] = 'Hello World!'
#     return render(request, 'hello.html', context)

def hello1(request):
    return HttpResponse("Hello world!")