from django.apps import AppConfig


class SancengConfig(AppConfig):
    name = 'sanceng'
