from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from . import models
# from .models import Tblm
from django.http import HttpResponse

import json
# Create your views here.
def hello(request):
    return render(request,"hello.html")
def hello1(request):
    return render(request,"hello1.html")

def index(request):
    #article = models.Article.objects.get(pk=2)
    #return render(request, 'blog/index.html', {'article': article})
    articles = models.Article.objects.all()
    return render(request,'blog/index.html',{'articles':articles})

def tblm(request):
    return render(request,"blog/tblm.html")

def location(request):
    return render(request,"blog/location.html")

def iteration(request):
    return render(request,"blog/iteration.html")

def indexxx(request):
    return render(request,"blog/indexxx.html")

def tblmdata(request):
    resultData = models.Tblm.objects.values('id', 'name', 'price')
    return HttpResponse(json.dumps( list(resultData)), content_type="application/json")



